# Judging Notes: Soil Memory

**One line:** NASA soil-moisture and vegetation records, turned into a measurable "soil memory" and a rotation comparison tool for farmers.

## Impact
Soil degradation is slow and invisible. Soil Memory quantifies how long moisture stress persists (tau), how soon vegetation responds, and whether land is greening or browning, then lets a farmer compare rotations before planting.

## Validity (what is real, what is not)
- NDVI: NASA MODIS MOD13Q1. Soil moisture: NASA SMAP L4 (or NASA POWER/MERRA-2 where noted in the app).
- The memory metrics are formulas, unit-tested against a process with a known answer.
- The rotation model is a scenario tool with illustrative inputs, not a forecast. Soil carbon is not observed from space; the farmer supplies a lab baseline.
- The app shows a banner naming the exact data source for every view.

## Creativity
Existing tools show a snapshot. We quantify persistence (memory) and link it to rotation choices.

## Product
Streamlit dashboard with three views (trajectory, soil memory, rotation lab). Real data is precomputed, so it works offline and cannot fail during a live demo.

## Sustainability
Open-source, free NASA data, forkable. Distribution through agricultural extension agents. Planned: Arabic/French UI, offline PDF report.

## Presentation
Story: Farmer Dalal on the Doukkala plain cannot see her soil changing. Live demo, backed by a recorded video.

# 🌱 Soil Memory

**Reading what the soil remembers.** NASA Space Apps 2026.

Soil degradation is slow and invisible. Soil Memory turns a decade of NASA satellite
observations into a quantified *memory* of how a region's soil moisture and vegetation
respond to stress, then lets a farmer compare crop rotations on screen before planting.

[**▶ Live demo**](https://soil-memory-c823saskmqktzfmb3racfw.streamlit.app/) ·
[Demo video](#) · [Method](#method) · [Limitations](#limitations)

<!-- ![dashboard screenshot](docs/dashboard.png) -->

---

## The problem

A farmer sees this year's yield. They cannot see that moisture-stress years are lasting
longer, that vegetation is slowly browning, or that their rotation is drawing down soil
carbon. By the time it is visible, it is expensive to reverse.

## What it does

| Tab | Question it answers |
|---|---|
| **Trajectory** | What have NDVI and soil moisture done here since 2015? |
| **Soil memory** | How long does a moisture anomaly persist (τ)? How many months later does vegetation respond? Is the land greening or browning? |
| **Rotation lab** | Over 5–30 years, how do two rotations compare in soil-carbon balance, given this region's moisture regime? |

## Real vs simulated (read this first)

| Component | Status |
|---|---|
| NDVI | ✅ NASA MODIS MOD13Q1 (250 m, 16-day → monthly), via ORNL DAAC MODIS web service or Earth Engine |
| Soil moisture, `--source gee` | ✅ NASA **SMAP L4** SPL4SMGP (9 km) |
| Soil moisture, `--source open` (no account) | 🟡 NASA **POWER / MERRA-2** soil wetness. A NASA *model reanalysis* (~50 km), **not SMAP** |
| Soil-memory metrics (τ, lag, trend) | ✅ Implemented and unit-tested |
| Rotation SOC model | ✅ Implemented; **crop inputs are illustrative assumptions** |
| Regions with no cache file | 🟠 Fall back to a **synthetic generator**; the app shows a warning banner |
| Validation against field SOC | 🔴 Not done. See [roadmap](#roadmap) |

The banner in the app is driven by the provenance stored with each dataset, and
cache files are rejected if values are out of physical range, so the UI cannot label
simulated data as real.

## Architecture

```
 NASA GEE catalog ─► scripts/fetch_real_data.py ─► data/cache/<region>.csv   (run once, online)
                                                          │
 lat/lon, years ─► core.load_series() ◄───────────────────┘   (else: labeled synthetic)
                          │
              ┌───────────┴────────────┐
      core.memory_metrics()     core.simulate_rotation()
              └───────────┬────────────┘
                     app.py (Streamlit)
```

**Offline-first by design.** Real data is precomputed and shipped with the app, so it works
with no connection in the field. Computation is a few hundred rows of pandas.

## Method

**Datasets**
- SMAP L4 `SPL4SMGP` (`--source gee`): 9 km surface soil moisture (m³/m³), model-assimilated; record begins Mar 2015.
- NASA POWER `GWETTOP` (`--source open`): surface soil wetness (0–1) from MERRA-2 reanalysis, used when no Earth Engine account is available. Labeled as such in the app.
- MODIS `MOD13Q1`: 250 m NDVI, 16-day composites, aggregated to monthly.

**Soil-memory metrics.** Remove the mean seasonal cycle to get anomalies, then:
- *Persistence* τ = −Δt / ln(r₁), where r₁ is the lag-1 autocorrelation of soil-moisture
  anomalies (Δt = 1 month). Larger τ means droughts and wet spells linger.
- *Vegetation response lag*: the lag (0–3 months) maximising corr(NDVI anomaly, past moisture anomaly).
- *Trend*: linear slope of the deseasonalised NDVI anomaly (greening vs browning).

**Rotation model.** One-pool carbon balance, annual step:
`SOC(y+1) = SOC(y) + h·I(crop) − k·f(SM)·SOC(y)`
with humification h = 0.25, k = 0.02 /yr, and f(SM) = clip(mean SM / 0.25, 0.5, 1.3).
Per-crop residue inputs I are in `core.CROP_INPUT_TC_HA`. They are placeholders to be calibrated.

## Limitations

- **Scale gap.** One SMAP cell (~9 km) spans ~1,300 MODIS pixels. Soil moisture is a regional signal, not a per-field measurement.
- **Soil-moisture source matters.** Under `--source open` the moisture signal is a coarse reanalysis, so memory metrics describe regional behavior only.
- **SOC is not observed from space** by these products. The user supplies a measured baseline; the model only projects change.
- **Rotation outputs are scenarios**, not forecasts, until calibrated against long-term experiment data.
- **Short record.** SMAP begins in 2015, so τ estimates rest on ≤ ~11 years.

## Roadmap

1. Validate τ and NDVI trend against ISMN in-situ soil-moisture stations.
2. Calibrate the SOC model against published long-term rotation trials; add uncertainty bands.
3. Add SMAP L4 carbon (`SPL4CMDL`) and MODIS NPP as carbon-input drivers.
4. Draw-your-own-field polygon; offline PDF report for extension agents.
5. Arabic / French UI.

## Run locally

```bash
git clone https://github.com/doublanewiam-tech/soil-memory.git && cd soil-memory
pip install -r requirements.txt

# 1. Get real NASA data (pick one; commit the resulting data/cache/*.csv)
python scripts/fetch_real_data.py --only doukkala        # smoke test, no account needed
python scripts/fetch_real_data.py                         # all regions, no account needed
python scripts/fetch_real_data.py --source gee            # true SMAP (needs Earth Engine login)

# 2. Test and run
python tests/test_core.py && python tests/test_fetch_parsing.py
streamlit run app.py
```

## Data credits & license

NASA SMAP L4 (NSIDC DAAC) · NASA MODIS MOD13Q1 (LP DAAC) · accessed via Google Earth Engine.
Code: MIT (add a `LICENSE` file). Team: _add names and roles_.
